print(type(15*3))
print(type(15/3))
print(type(15//2))
print(type(15**2))