list = ['в', '5', 'часов', '17', 'минут', 'температура', 'воздуха', 'была', '+5', 'градусов']
# for i in range(len(list)):
#     list[1] = '"' + list[1] + '"'
#     list[3] = '"' + list[3] + '"'
#     list[8] = '"' + list[8] + '"'
# print(list)
colon = '"'
list.insert(1, colon)
list.insert(3, colon)
list.insert(5, colon)
list.insert(7, colon)
list.insert(12, colon)
list.insert(14, colon)
list[2] = "05"
list[13] = "+05"
print(f'{list[0]} {list[1]} {list[2]} {list[3]} {list[4]} {list[5]} {list[6]} {list[7]} {list[8]} {list[9]} {list[10]} {list[11]} {list[12]} {list[13]} {list[14]} {list[15]}')