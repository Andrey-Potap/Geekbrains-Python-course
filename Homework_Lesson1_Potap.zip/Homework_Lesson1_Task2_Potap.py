list =[]
i = 0
for i in range(1, 1000):
    if i % 2 != 0:
        y = i ** 3
        list.append(y)
        i += 1
print(list)
for y in list:
    total = 0
    digit_sum = 0
    temp_number = y
    while temp_number > 0:
        digit_sum += temp_number % 10
        temp_number = temp_number // 10
    if digit_sum % 7 == 0:
        total += digit_sum
        print(total)
for idx in range(len(list)):
    list[idx] += 17
print(list)
for y in list:
    total = 0
    digit_sum = 0
    temp_number = y
    while temp_number > 0:
        digit_sum += temp_number % 10
        temp_number = temp_number // 10
    if digit_sum % 7 == 0:
        total += digit_sum
        print(total)