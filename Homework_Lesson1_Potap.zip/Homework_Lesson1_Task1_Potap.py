duration = int(input("Введите продолжительность в секундах (целое числое не меньше 0)"))
if duration <= 59:
    print(duration, "сек")
else:
    if duration >= 60 and duration <= 3599:
        minute = duration // 60
        remainder = duration - minute * 60
        print(minute, "мин.", remainder, "сек.")
    else:
        if duration >= 3600:
            hour = duration // 3600
            minute = (duration - (hour * 3600)) // 60
            remainder = duration - (hour * 3600) - (minute * 60)
            print(hour, "ч.", minute, "мин.", remainder, "сек.")