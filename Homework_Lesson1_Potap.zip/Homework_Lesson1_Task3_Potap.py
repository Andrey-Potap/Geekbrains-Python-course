number = int(input('Введите количество процентов от 1 до 20'))
if number <= 0 or number > 20:
    print("Вы ввели неверное число. Попробуйте запустить программу снова и введите числе межд 1 и 20")
if number == 1:
    print(number, "процент")
if number >= 2 and number <= 4:
    print(number, "процента")
if number >= 5 and number <= 20:
    print(number, "процентов")